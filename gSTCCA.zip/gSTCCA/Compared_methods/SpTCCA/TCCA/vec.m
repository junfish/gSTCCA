function[vecx] = vec(X)
vecx = X(:);